# Joomla! Sytyle Guide Component

A super simple [Joomla!](http://www.joomla.org/) component to create a website Style Guide.

Simply install, review / edit style guide html, then add a Style Guide menu item...
